<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="KMTronic LTD" />
<meta name="description" content="KMTronic LTD" />
<meta name="keywords" content="KMTronic LTD Mobile" />
<title>KMTronic Mobile</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" />
<!-- Hide Mobiles Browser Navigation Bar -->
<script type="text/javascript">
	window.addEventListener("load",function() {
	// Set a timeout...
	setTimeout(function(){
	// Hide the address bar!
	window.scrollTo(0, 1);
	}, 0);
	});
</script>
<style type="text/css">
<!--
body {
	background-image: url(img/top_bg.jpg);
}
-->
</style></head>

<body>
<div id="main_container">
	<div class="logo">
    <a href="index.html" ><img src="img/logo.png" alt="" width="220" height="192" border="0" title="" /></a>    </div>
     
    
	<div class="menu">
    	<ul>
            <li><a href="relay.php"><img src="img/icon1.png" alt="" width="85" height="85" border="0" title=""/>Relays</a></li>
        </ul>
    </div>


</div>
</body>
</html>
